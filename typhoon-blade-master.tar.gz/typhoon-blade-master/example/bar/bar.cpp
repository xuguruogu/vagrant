#include "bar/bar.h"

#include <iostream>
#include "common/common.h"

void Bar()
{
    Common();
    std::cout << "Bar" << "\n";
}
