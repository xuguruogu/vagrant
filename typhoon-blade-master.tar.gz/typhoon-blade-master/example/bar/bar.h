#ifndef BAR_BAR_H
#define BAR_BAR_H
#pragma once

void Bar();

#endif // BAR_BAR_H
