#ifndef FOO_FOO_H
#define FOO_FOO_H
#pragma once

void Foo();

#endif // FOO_FOO_H
